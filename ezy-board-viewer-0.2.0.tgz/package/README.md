# ezy-board-viewer

Vue 3 + Element Plus 组件，读取「随身答 / 中育云笔记」画板导出的 zip：

- **静态页**：直接渲染（矢量，可无损缩放）。
- **录制**：直接播放（画面 + 音频），底部浮动控制条：进度条、播放/暂停、静音、倍速（音频同步倍速）。
- 桌面 `Ctrl + 滚轮` / 触控板捏合缩放，移动端双指缩放，右下角 `+` `-` 按钮；拖动平移。
- 右键 / 长按菜单：**保存为 SVG**；录制另有 **保存为 MP4**（流畅 960p / 标准 1280p / 高清 1920p）。
- UI 全部使用 Element Plus 组件、图标（`@element-plus/icons-vue`）与默认主题变量，随暗色模式变化。

> npm 包名不允许大写，所以包名是 **`ezy-board-viewer`**，组件名是 **`EzyBoardViewer`**。

## 安装

```bash
npm i ezy-board-viewer element-plus @element-plus/icons-vue vue
```

组件内部显式引入了所用的 Element Plus 组件，但**不会**自带样式，请在应用里照常引入（完整引入或 `unplugin-element-plus` 按需引入均可）：

```js
import 'element-plus/dist/index.css'
// 暗色模式（可选）
import 'element-plus/theme-chalk/dark/css-vars.css'
```

## 使用

```vue
<script setup>
import { EzyBoardViewer } from 'ezy-board-viewer'
</script>

<template>
  <!-- 根节点就是一个 div：class / style 照常使用。没有设置高度时最小高度为 200px -->
  <EzyBoardViewer source="/files/note.zip" style="height: 480px" file-name="note" @loaded="console.log" />
</template>
```

`source` 可以是 `Blob` / `File` / `ArrayBuffer` / `Uint8Array`，或一个 URL 字符串（组件自己 `fetch`，跨域需服务端允许 CORS）：

```vue
<input type="file" accept=".zip" @change="e => (file = e.target.files[0])" />
<EzyBoardViewer :source="file" class="board" />
```

全局注册：`app.use(EzyBoardViewer)`。

## Props

| 名称 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `source` | zip（`Blob`/`File`/`ArrayBuffer`/`Uint8Array`/URL）、**文件列表 `[{ path, blob }]`**、或 `createBoard()` 返回的画板 | — | 数据来源，变化时重新载入 |
| `mode` | `'auto' \| 'static' \| 'recording'` | `'auto'` | 自动识别：含音频文件 / `AUDIO_START` / `RECORD_STOP` / 激光笔 / `Header.duration>0` / `router.audioRecord` 任一即为录制 |
| `autoplay` | `boolean` | `true` | 录制载入后自动播放（浏览器拦截音频自动播放时，用户首次点击后恢复） |
| `loop` | `boolean` | `false` | 循环播放 |
| `muted` | `boolean` | `false` | 初始静音 |
| `speeds` | `number[]` | `[0.5,0.75,1,1.25,1.5,2]` | 倍速档位 |
| `audioAnchor` | `'chain' \| 'segment'` | `'chain'` | 音频起点计时基准，见下方"已知限制" |
| `minZoom` / `maxZoom` | `number` | `0.25` / `8` | 缩放范围，相对"适应窗口" |
| `fileName` | `string` | `'board'` | 导出文件名（不含扩展名） |
| `fetchOptions` | `RequestInit` | — | `source` 为 URL 时传给 `fetch` |
| `contextMenu` | `boolean` | `true` | 右键 / 长按菜单 |

## 事件

`loaded({ kind, pages, duration })` · `error(err)` · `play` · `pause` · `ended` · `timeupdate(ms)`（约 4 次/秒）

## 实例方法（`ref`）

`zoomIn()` `zoomOut()` `resetView()` `play()` `pause()` `toggle()` `seek(ms)` `setRate(n)` `setMuted(b)`

导出（**返回 `Blob`**，默认不触发下载，传 `download: true` 才下载）：

```js
const svg = await viewer.value.exportSvg()                       // Blob，多页纵向合并
const mp4 = await viewer.value.exportMp4({ quality: 'high', onProgress: (stage, frac) => {}, signal })
// quality: 'low' | 'mid' | 'high' | { long: 长边像素, kbps }；仅录制内容
```

## 文件列表作为来源

不想先打成 zip 时，直接传 `{ path, blob }` 列表（路径相对 zip 根；`./`、反斜杠会被规范化）：

```js
const files = [
  { path: 'page_router.bin', blob: ... },
  { path: '<page-uuid>/header.bin', blob: ... },
  { path: 'res/image/<uuid>.png', blob: ... }
  // ...
]
```
```vue
<EzyBoardViewer :source="files" />
```

## 不挂载组件：程序化导出

```js
import { boardToSvgBlob, boardToSvgs, boardToMp4Blob, filesToZip } from 'ezy-board-viewer'

const svg  = await boardToSvgBlob(source)                         // Blob（多页合并）
const each = await boardToSvgs(source)                            // [{ svg } | { error }]，每页一个
const mp4  = await boardToMp4Blob(source, { quality: 'mid', onProgress, signal })   // 仅录制；静态内容抛错，force:true 可强制按命令回放
const zip  = await filesToZip(files)                              // [{ path, blob }] → zip Blob
```
`source` 与组件相同（zip / 文件列表 / 画板）。MP4 需要 WebCodecs。

## 交互说明

- 滚轮：内容大于窗口时平移；`Ctrl/⌘ + 滚轮`缩放（以光标为中心）。
- 触屏：单指拖动平移，双指缩放，**长按 0.55 秒**弹出菜单。
- 多页静态：纵向排列；导出 SVG 时合并成一个文件。
- 录制的 SVG 是**最终画面**（取自 `snapshot.bin`）。

## MP4 导出

- 使用 WebCodecs（H.264 + AAC）离线逐帧渲染，时间戳取自文件时间轴，不依赖实时录屏；需要较新的 Chrome / Edge / Safari。
- 浏览器不支持 AAC 编码时，导出的 MP4 没有声音（会弹出提示）。
- 导出过程中会暂停播放，可点进度条旁的关闭按钮取消。

## 创建新画板

`createBoard({ width, height })` 生成与 App 同格式的画板：同时写出命令流、各数据文件、`snapshot.bin`、`router.bin`（含 SHA-256）和 `header.bin`。产物用真实 `.proto` 生成的类解码、哈希校验过。

```js
import { createBoard } from 'ezy-board-viewer'

const board = createBoard({ width: 1280, height: 720, background: '#ffffff' })
const page = board.page()                       // 第一页已创建；更多页：board.addPage()

await page.image(blob, { x: 60, y: 40 })        // 宽高自动识别 PNG/JPEG/GIF/WebP（也可传 width/height）
page.stroke([[100, 100], [160, 130], [240, 120]], { color: '#ff4931', lineWidth: 6 })
page.line([700, 120], [1100, 300], { color: '#40CA00', lineWidth: 8, dash: [30, 15] })   // 虚线 = [实线长, 间隔]
page.text('随身答', { x: 120, y: 420, size: 48, color: '#333' })
page.oval({ x: 800, y: 80, width: 300, height: 160 })
page.polygon([[200, 600], [350, 520], [500, 600]])
page.rect({ x: 900, y: 450, width: 200, height: 160 })

// 作为 source 直接给组件，或取出文件
<EzyBoardViewer :source="board" />
const files = await board.toFiles()             // [{ path, blob }]
const zip   = await board.toBlob()              // zip Blob
```

**协议里每一类内容对应的方法**

| 内容 | 方法 |
|---|---|
| 图元：图片 / 手绘 / 直线（含虚线）/ 文字 / 椭圆 / 多边形 / 分组 | `image` `stroke` `line` `text` `oval` `polygon`（`rect` 是多边形的简写）`group` |
| `GRAPH_MATRIX` 变换手势（拖动/缩放/旋转） | `move(handle, { dx, dy, scale, rotate, pivot, duration })` |
| `GRAPH_CHANGE` 改属性 | `change(handle, { content, color, size, lineWidth, dash, width, height, points })` |
| `GRAPH_REMOVE` / `REBUILD` | `remove(handle)` / `rebuild()` |
| `CONFIG` 背景色、背景线 | `config({ background, backgroundLine })` |
| `CAMERA` / `CAMERA_MATRIX` | `camera({ scale, dx, dy })` / `cameraMove({ ... })` |
| `CURSOR_MOVE` 激光笔 | `cursor(points, { duration })` |
| `GRAPH_CUSTOM` | `custom(bytes)` |
| `AUDIO_START` 音频 | `await audio(blob, { start, duration })` |
| `RECORD_STOP` | `stop()` |
| `Header`：作者、素材提供人、背景、背景线、`moveConfig`、`convertUrl` | `createBoard({ author, provider, background, backgroundLine, moveConfig, convertUrl })` |

**静态 or 录制**：`recording: 'auto'`（默认）下，只要加了音频、`stop()` 或激光笔，就按录制输出（`Header.duration > 0`、末尾补 `RECORD_STOP`）；也可 `recording: true / false` 强制。

**录制的时间**：每条命令的 `delayTime` = 它开始前的等待，`duration` = 它自身时长（笔迹的点时间、手势的帧时间会自动生成，与 `duration` 一致）。用 `page.wait(ms)` 或每个方法的 `delay` 选项制造间隔。

```js
const rec = createBoard({ width: 1280, height: 720 })
const p = rec.page()
p.stroke(points, { duration: 600 })              // 0 ~ 600ms 书写
p.wait(400)
const t = p.text('先写一行字', { x: 100, y: 300 })
p.move(t, { dy: -120, duration: 500 })           // 拖动 500ms
await p.audio(mp3Blob, { start: 183, duration: 2880 })   // 主时间轴上 0.183s 开始播放（_audio.bin 命令链计时）
p.stop()
```

> `audio()` 的 `start` 是**主时间轴上的毫秒**，同一页内按先后顺序、不能重叠。`duration` 在浏览器里缺省时自动探测，在 Node 里必须传。

## 已知限制

- **音频起点基准尚未能确认**。`_audio.bin` 自己的命令链与主时间轴上 `RECORD_STOP` 的对应关系，文件内没有证据。默认 `audioAnchor="chain"`（文件字面），若发现声音与笔迹错位，改为 `"segment"` 对照。
- 以下**没有真实 App 样本**，生成与播放只是自洽，未与 App 对照：激光笔 `CURSOR_MOVE`（数据按 `touch.bin` 约定）、背景线可见时的外观（`staggered` 按网格画）、`GRAPH_CUSTOM`、`CAMERA` / `CAMERA_MATRIX`、`GRAPH_REMOVE`（App 里的删除是 `REBUILD`）。
- 生成器不写 `PageHeader`（样本里没有对应文件）；`Header.duration` 取时间轴总长（真实录制里比命令流略短，原因未知）。
- 生成器里"每段录制从 RECORD_STOP 重新计时"的音频方式不提供，音频起点一律按命令链写。
- 文字依赖系统中文字体（SVG 里是 `<text>`）。
- 不支持 zip64。
- 画布内容按页面原始分辨率绘制，放大很多倍时录制画面会变糊（静态页是矢量，不受影响）。
